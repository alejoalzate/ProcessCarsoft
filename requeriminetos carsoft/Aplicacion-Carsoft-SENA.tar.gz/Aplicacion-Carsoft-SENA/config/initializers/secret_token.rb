# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Carsoft::Application.config.secret_token = '73b3696fa1c10cfbe63a3dc68f8f66983b1fbd37656899ce926e67a6108baa3484ef837dc4f73afe1471e45d96271a1a6a6d6231d0e7a9dffc65d1c188d9784c'
