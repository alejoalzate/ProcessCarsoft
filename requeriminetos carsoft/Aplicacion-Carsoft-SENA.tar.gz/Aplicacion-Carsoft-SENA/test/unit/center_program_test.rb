require 'test_helper'

class CenterProgramTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
