require 'test_helper'

class CentersHelperTest < ActionView::TestCase
end
