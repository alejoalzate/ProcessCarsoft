require 'test_helper'

class UsabilitiesHelperTest < ActionView::TestCase
end
