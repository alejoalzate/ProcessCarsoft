require 'test_helper'

class ResponsiblesHelperTest < ActionView::TestCase
end
