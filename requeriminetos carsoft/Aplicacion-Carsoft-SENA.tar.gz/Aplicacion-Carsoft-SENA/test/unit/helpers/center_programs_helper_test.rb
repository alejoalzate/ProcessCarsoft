require 'test_helper'

class CenterProgramsHelperTest < ActionView::TestCase
end
