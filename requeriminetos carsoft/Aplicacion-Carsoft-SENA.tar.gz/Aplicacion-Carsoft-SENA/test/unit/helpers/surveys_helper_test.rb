require 'test_helper'

class SurveysHelperTest < ActionView::TestCase
end
