require 'test_helper'

class TypeVehiclesHelperTest < ActionView::TestCase
end
