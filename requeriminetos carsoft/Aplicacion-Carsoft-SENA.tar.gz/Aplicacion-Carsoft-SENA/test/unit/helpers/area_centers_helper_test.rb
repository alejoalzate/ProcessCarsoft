require 'test_helper'

class AreaCentersHelperTest < ActionView::TestCase
end
