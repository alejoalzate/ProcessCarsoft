require 'test_helper'

class ParkingsHelperTest < ActionView::TestCase
end
