require 'test_helper'

class FormatSurveysHelperTest < ActionView::TestCase
end
