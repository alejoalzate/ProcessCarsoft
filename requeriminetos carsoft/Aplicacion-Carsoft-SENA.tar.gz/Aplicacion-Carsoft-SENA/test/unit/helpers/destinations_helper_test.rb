require 'test_helper'

class DestinationsHelperTest < ActionView::TestCase
end
