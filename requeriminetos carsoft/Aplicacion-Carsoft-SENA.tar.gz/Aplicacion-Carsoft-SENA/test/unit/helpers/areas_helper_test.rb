require 'test_helper'

class AreasHelperTest < ActionView::TestCase
end
