require 'test_helper'

class AuthorizationsHelperTest < ActionView::TestCase
end
