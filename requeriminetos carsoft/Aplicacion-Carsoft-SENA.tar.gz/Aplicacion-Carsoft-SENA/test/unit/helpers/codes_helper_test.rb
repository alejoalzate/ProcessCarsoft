require 'test_helper'

class CodesHelperTest < ActionView::TestCase
end
