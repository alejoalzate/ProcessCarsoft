require 'test_helper'

class CenterTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
