require 'test_helper'

class UsabilityTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
