require 'test_helper'

class FormatSurveyTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
