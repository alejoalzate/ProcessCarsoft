require 'test_helper'

class ResponsibleTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
