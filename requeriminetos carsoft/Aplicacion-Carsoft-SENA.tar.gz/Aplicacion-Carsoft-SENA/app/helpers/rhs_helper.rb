module RhsHelper
end
